---
                title: "chris.banes.dev"
                tags: [Personal site]
                externalUrl: "https://chris.banes.dev"
                date: 9989-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
