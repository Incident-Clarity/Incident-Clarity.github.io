---
                title: "alanctanner.com"
                tags: [Personal site]
                externalUrl: "https://alanctanner.com/"
                date: 9965-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
