---
                title: "theindiecoder.cloud"
                tags: [Personal site]
                externalUrl: "https://theindiecoder.cloud"
                date: 9949-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
