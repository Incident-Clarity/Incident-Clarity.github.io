---
                title: "dizzytech.de"
                tags: [Personal site]
                externalUrl: "https://dizzytech.de"
                date: 9978-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
