---
                title: "nick.bouwhuis.net"
                tags: [Personal site]
                externalUrl: "https://nick.bouwhuis.net"
                date: 9973-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
