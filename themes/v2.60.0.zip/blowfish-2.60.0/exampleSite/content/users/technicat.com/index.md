---
                title: "technicat.com"
                tags: [Company site]
                externalUrl: "https://technicat.com/"
                date: 9969-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
