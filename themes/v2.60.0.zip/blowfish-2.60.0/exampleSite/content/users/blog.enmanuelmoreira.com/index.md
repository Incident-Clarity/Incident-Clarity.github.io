---
                title: "blog.enmanuelmoreira.com"
                tags: [Personal site]
                externalUrl: "https://blog.enmanuelmoreira.com"
                date: 9959-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
