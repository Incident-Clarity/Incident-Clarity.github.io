---
                title: "scottmckendry.tech"
                tags: [Personal site]
                externalUrl: "https://scottmckendry.tech"
                date: 9946-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
