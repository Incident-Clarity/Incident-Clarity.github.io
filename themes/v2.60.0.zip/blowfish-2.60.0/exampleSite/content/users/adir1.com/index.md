---
                title: "adir1.com"
                tags: [Personal site]
                externalUrl: "https://adir1.com/"
                date: 9976-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
