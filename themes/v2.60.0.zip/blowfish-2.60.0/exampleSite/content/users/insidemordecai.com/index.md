---
                title: "insidemordecai.com"
                tags: [Personal site]
                externalUrl: "https://insidemordecai.com"
                date: 9984-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
