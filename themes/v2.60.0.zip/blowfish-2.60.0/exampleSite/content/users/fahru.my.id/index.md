---
                title: "fahru.my.id"
                tags: [Personal site]
                externalUrl: "https://www.fahru.my.id"
                date: 9988-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
