---
                title: "renaud.warnotte.be"
                tags: [Personal site]
                externalUrl: "https://renaud.warnotte.be"
                date: 9936-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
