---
                title: "mucahitkurtlar.github.io"
                tags: [Personal site]
                externalUrl: "https://mucahitkurtlar.github.io"
                date: 9996-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
