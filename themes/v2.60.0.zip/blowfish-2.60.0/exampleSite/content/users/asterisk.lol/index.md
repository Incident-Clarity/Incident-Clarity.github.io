---
                title: "asterisk.lol"
                tags: [Blog,Personal Site]
                externalUrl: "https://asterisk.lol"
                date: 9928-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
