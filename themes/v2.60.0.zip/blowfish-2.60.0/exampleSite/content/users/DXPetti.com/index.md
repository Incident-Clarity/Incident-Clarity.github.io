---
                title: "DXPetti.com"
                tags: [Personal site,Blog]
                externalUrl: "https://www.dxpetti.com/"
                date: 9929-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
