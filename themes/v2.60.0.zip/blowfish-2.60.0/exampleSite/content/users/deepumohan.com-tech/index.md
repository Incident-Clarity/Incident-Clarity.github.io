---
                title: "deepumohan.com/tech"
                tags: [Technology Blog]
                externalUrl: "https://deepumohan.com/tech/"
                date: 9942-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
