---
                title: "talkdimsum.com"
                tags: [App site]
                externalUrl: "https://talkdimsum.com/"
                date: 9966-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
