---
                title: "aakashnand.com"
                tags: [Personal site]
                externalUrl: "https://aakashnand.com/"
                date: 9924-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
