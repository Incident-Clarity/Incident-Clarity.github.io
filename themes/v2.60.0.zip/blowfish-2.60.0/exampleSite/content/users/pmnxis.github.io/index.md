---
                title: "pmnxis.github.io"
                tags: [Personal site]
                externalUrl: "https://pmnxis.github.io"
                date: 9993-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
