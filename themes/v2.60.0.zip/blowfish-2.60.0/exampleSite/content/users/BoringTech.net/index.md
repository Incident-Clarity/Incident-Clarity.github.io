---
                title: "BoringTech.net"
                tags: [Personal Site,Blog]
                externalUrl: "https://boringtech.net/"
                date: 9935-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
