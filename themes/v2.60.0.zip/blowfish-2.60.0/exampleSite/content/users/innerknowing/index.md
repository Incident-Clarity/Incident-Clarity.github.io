---
                title: "innerknowing"
                tags: [Personal site,Modeller]
                externalUrl: "https://innerknowing.xyz"
                date: 9923-08-08
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
