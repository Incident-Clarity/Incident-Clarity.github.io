---
title: Advanced
---

This is the advanced tag. Just like other listing pages in Blowfish, you can add custom content to individual taxonomy terms and it will be displayed at the top of the term listing. :rocket:

You can also use these content pages to define Hugo metadata like titles and descriptions that will be used for SEO and other purposes.
